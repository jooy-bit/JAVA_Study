package koreait.tset;
public Product(){

    public abstract Product {
        protected int price;
        
    }
    protected String ProductName() {
        this.prdName = prdName; 
    
    }
    
    public abstract sell (object sellName){
        return (String) sellName;
    }
    
}